| Route | Result | Tests |
|---|---|---|
| PostgreSQL 16 local Adapter | pass | 146 |
| PostgreSQL 16 cluster role/recovery | pass | 1 |
| PostgreSQL 16 cluster Adapter | pass | 146 |
| PostgreSQL 16 cluster durable projection | pass | 10 |
| Packed projection host PostgreSQL 16 | pass | 39 |
| PostgreSQL 17 local Adapter | pass | 146 |
| PostgreSQL 17 cluster role/recovery | pass | 1 |
| PostgreSQL 17 cluster Adapter | pass | 146 |
| PostgreSQL 17 cluster durable projection | pass | 10 |
| Packed projection host PostgreSQL 17 | pass | 39 |
| Standalone released projection runner PostgreSQL 16 | pass | 10 |
| ClickHouse standalone/restart/backup/restore/cursor | pass | 32 |
| ClickHouse Keeper/replica recovery | pass | 3 |
| OpenSearch single | pass | 1 |
| OpenSearch cluster real operations | pass | 1 |
| OpenSearch three-node | pass | 1 |
| OpenSearch node loss | pass | 1 |
| Valkey standalone restart | pass | 1 |
| Valkey Sentinel failover | pass | 1 |
| S3 MinIO | pass | 1 |
| OCI registry/core/referrers negative | pass | 4 |
| ConfigArtifact PostgreSQL/S3/OCI | pass | 21 |
| Cost/Usage/Evidence | pass | 16 |
| Observability actual ClickHouse/API | pass | 5 |
| Kafka full cluster/TLS/controller/broker recovery | pass | 11 |
| Usage PostgreSQL/Evidence and ClickHouse replay | pass-after-fixture-correction | 45 |
| Final corrected Constructs generic generated-config closure | unverified | — |
| Managed cloud apply/HA/provider lifecycle across 28 combinations | unverified | — |
| Collector image end-to-end OTLP/backend read | unverified | — |
| External owner-managed OCI registry service gate | unverified | — |
| OCI isolated S3 coexistence test with its hard-coded separate credentials | unverified | — |

{"passingTestInvocations": 838, "selectedFinalFailures": 0, "selectedSkipped": 0, "passingRoutes": 26, "unverifiedRoutes": 5}
