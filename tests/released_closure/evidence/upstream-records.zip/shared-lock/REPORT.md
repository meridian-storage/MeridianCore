# Shared public lock conformance — validation report

Validation/evidence work is complete for the task's independent local scope. This is **not all-family release closure**. The selected runtime routes pass; the public Constructs 1.4.0 metadata audit has confirmed mismatches that require the separate owning repair and subsequent closure run.

- **26 selected runtime routes, 838 passing test invocations, zero final selected failures or skips.** Counts include repeated tests on distinct PostgreSQL versions/topologies, not 838 unique test functions. One Usage case passed after correcting the disposable test user's privileges; its original failures remain attached.
- **12 profiles, 28 allowed mode/topology combinations, 2,454 metadata cases, 168 mismatches.** These comprise 72 PostgreSQL false rejections and 96 ClickHouse selected-limit false acceptances. The 978 negative cases include those 96 false acceptances. Metadata plans do not prove cloud deployment or authenticated engine capabilities.
- **18 Meridian packages in the unchanged 61-distribution public closure**, normal dependency resolution with required hashes, installed discovery, final `pip check`, and 36 wheel/sdist provenance verifications passed. Test-only tools add 13 distributions without changing any original pin.
- All task-owned disposable containers, networks and volumes were removed. No owning source implementation, reserved branch, PR, package release or production deployment was changed.

## Scope and authority

Task: [Validate adapters plugins and hosts on the final public lock](https://applink.feishu.cn/client/todo/detail?guid=acc7f730-a62c-4318-8523-2e9b9a12a18b&suite_entity_num=t100654).
Authority: [Platform Software Development Guide](https://qcnwge0wy4s0.feishu.cn/wiki/NeuUwUNtdi9sNVkoyM0cYk7inpf), [Core design](https://qcnwge0wy4s0.feishu.cn/docx/MqvjdSUZhoGOqixD8LDctodEnZc), and [Constructs design §6](https://qcnwge0wy4s0.feishu.cn/wiki/D5MBwLF2di54gJkv24fcg26Ungh). The task explicitly assigns the corrected generic generated-config route to the separate closure after the owning public release.

See `RESULTS.md` and `results/route-matrix.json` for the per-route pass/unverified matrix and exact JUnit paths. `REPRODUCE.md` records the invocation recipe; `scripts/run_selected.py` prints or runs the individual direct test commands. Source fixtures are retained in this bundle; packages under test were imported from installed public distributions, not their extracted implementation directories.

## Public artifacts and runtime identity

`requirements.txt` records the 18 Meridian pins; `public-requirements.lock`, `public-artifacts.json` and `installation.json` bind the full original 61 distributions and selected hashes. Validation ran with CPython 3.13.3 on macOS arm64. `runtime-constraints.txt` constrained the supplemental test tooling install; `tooling-installation.json`, `full-test-requirements.lock`, `results/full-test-artifact-lock.json` and `results/final-installed-environment.json` record its resulting 74 locked distributions. Pip 26.2.1 is an external seed tool, making 75 installed distributions including pip. Final checking confirmed every original pin unchanged.

The public npm consumer is `@zephytiju/meridian-storage-constructs@1.4.0`, with an exact consumer `package-lock.json`. Its tarball SHA-256 is `f35cb9fcc1d0e3d5bead81c8cc12d0340cdeeb37d7981e11c3bd35da0c48146c`. Exact public 1.1.0 is installed separately for the unchanged legacy-host required-Evidence negative control. `tsx@4.23.12` is test tooling. `npm audit signatures --json` exited successfully with no invalid or missing signatures (`logs/npm-signatures.json`). The host tests exercise actual packaged Python worker/supervisor/target files and subprocesses; the fixture's placeholder host image string is **not** a deployed image claim.

All 36 Meridian wheels/sdists passed the public `pypi-attestations` verifier (0.0.30) against their owning repositories. `results/provenance-verification.json` retains first attempts and retries; three transient trust-metadata refresh failures succeeded on sequential retry. S3's PyPI Repository URL points to `zephytiju/meridian-storage-s3.git`, whereas its signed owning repository is `zephytiju/MeridianS3Adapter`. Verification succeeds against the latter; the stale metadata URL is retained as an ancillary finding, not concealed or described as a signature failure.

ClickHouse and OCI sdists omit their test suites. Their fixtures came from exact public release commits, also matched to artifact attestations. Constructs fixtures likewise came from its exact release commit. `results/released-source-fixtures.json`, `results/public-fixtures.json` and `artifacts/` retain commits, archive material and hashes. The retrieval-time `public-fixtures.json` status predates signature verification; the final verifier results are authoritative. A byte comparison of 1,317 extracted public archive files found zero modifications (`results/fixture-integrity.json`). PostgreSQL source commit is `6110272c97c4586d3896f5e7fa4ebf91752869ae`, bound by verified release provenance.

## Engine and host coverage

PostgreSQL 16 and 17 each passed the local Adapter suite, primary/standby recovery suite, cluster Adapter suite, durable projection suite, and 39 packed host cases. Required atomic Evidence and outbox remain on the same binding. Coverage retains restart/claim/exact acknowledgement, replay of v1 after v2, latest values and tombstones, graceful drain, failed drain and lease-expiry recovery, and negative contract/pin controls. The standalone released projection runner also passed on PostgreSQL 16.

Other selected routes exercise ClickHouse standalone/restart/backup/restore/cursor and Keeper/replica recovery; OpenSearch single/three-node/node-loss; Valkey restart/Sentinel failover; MinIO object conformance; OCI reference registry, public Core runtime and required-referrers rejection; Kafka 4.3.1 full authenticated/TLS and controller/broker disruption; and the applicable Usage, Cost, ConfigArtifact and Observability integration suites. Kafka's full gate is 11 passing cases with zero skips.

Exact observed engine versions and platform-qualified immutable image identities are in `results/*observed.txt`, `results/engine-images*.txt`, `results/postgresql-cluster-images.txt`, `results/postgresql16-cluster-image-binary.txt` and Kafka's native result JSON. PostgreSQL local 16 is 16.4/PostGIS 3.4.3; 17 is 17.11/PostGIS 3.5.7; ClickHouse is 25.8.33.6; MinIO is RELEASE.2025-04-22T22-12-26Z; reference registry is 3.1.1. PostgreSQL uses linux/amd64 images under the arm64 host; other captured engines use linux/arm64. OpenSearch's ICU image is derived with the published Dockerfile from its pinned 2.19.1 base; the retained local image identity is not a claim of a separately published registry artifact.

## Confirmed metadata defects

The initial audit remains intact: `profile-audit.json`/`profile-mismatches.json`, 1,146 cases, 52 PostgreSQL mismatches, 216 passing unsupported-version negatives. Its native interim attachment remains available.

The expanded authoritative audit is `profile-audit-extended.json`/`profile-mismatches-extended.json`: 2,454 cases and 168 mismatches. The expansion includes supported and one-above-limit cases plus unsupported-guarantee negatives. Actual released Core capability checks are compared with public Constructs planning and deterministic runtime-config validation, using the same selected manifest and binding settings.

PostgreSQL's 72 false rejections span both profiles and modes: the original 52 scope-isolation, durable/immutable schema publication, no-runtime-DDL, structured.put 2.0.0 and atomic-evidence requirements, plus 20 put 2.0.0 limit cases.

ClickHouse's 96 false acceptances span six operations × four selected limits × two profiles × two modes. Validated published fixture layouts select `maxBatchRows=100`, `maxTimeRangeSeconds=86400`, `maxBatchBytes=8388608` and `retryWindowSeconds=300`. The released settings parser accepts that binding and its manifest reflects those settings. Core rejects required minima 101, 86401, 8388609 and 301; Constructs 1.4.0 accepts them. The metadata resources and fingerprints are synthetic test inputs, explicitly not authenticated cloud proof.

Both evidence sets were attached to the native task and acknowledged by the coordinator, who routed them to the existing owning capability repair. This worker does not claim a later candidate or public release fixes the 168 cases.

## Fixture corrections and evidence limitations

- S3 initially could not collect without its declared Moto test dependency. Supplemental tooling was installed with all original pins constrained; the same real MinIO case then passed.
- Usage initially passed 44 of 45 cases. Its disposable ClickHouse user lacked required privileges; a second attempt still lacked OPTIMIZE. After `GRANT CURRENT GRANTS ON *.* TO usage`, the identical remaining test passed. All three JUnit/log files are retained. No assertion or implementation was changed.
- PostgreSQL cluster scratch initially lacked published `contracts` and `examples` fixtures. Restoring those unchanged fixtures resolved collection/runner failures; both final durable projection suites passed all ten cases. The post-test recorder still requires Git metadata and failed in the non-Git scratch directory. Test JUnit is valid; no successful recorder result is claimed. Exact source provenance is supplied separately, and the reproduction recipe supplies the true `GITHUB_SHA` for the recorder.
- OpenSearch cluster startup initially exited 137 while other engine suites were active. No Docker OOM event was captured, so an OOM cause is not asserted. The unchanged cluster fixture passed after other completed fixtures were torn down. Successful retry and teardown logs are retained.

Five explicitly unverified categories remain: corrected generic generated-config closure, managed cloud apply/HA/provider lifecycle, Collector image end-to-end OTLP/backend reads, an external owner-managed OCI endpoint, and the separate OCI/S3-coexistence test with its distinct fixed credentials. ConfigArtifact did pass real simultaneous S3/OCI discovery/storage, but this is not substituted for the omitted OCI test. The first three remain relevant to broader closure; this task's direct integration evidence does not clear them.

`results/cleanup-{containers,networks,volumes}.txt` are empty post-cleanup inventories scoped to owned test resources; cleanup logs are retained. Pre-existing platform/MCP resources were not touched. `SHA256SUMS` records bundle file hashes; the final ZIP checksum is supplied separately in the native task and coordinator callback to avoid a recursive checksum.
