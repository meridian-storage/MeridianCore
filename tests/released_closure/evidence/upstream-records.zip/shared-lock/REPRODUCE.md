# Reproduce the shared-lock evidence

Use a fresh extraction of the evidence bundle on macOS arm64 with CPython 3.13.3, Node/npm, Docker Compose and OpenSSL. The original run used disposable local engines; this recipe also provisions local fixtures. Run engine groups sequentially to avoid port collisions and excessive memory pressure. Run from the bundle root. These are equivalent reproduction commands assembled from the recorded routes, not a claim that every block was executed as a single original script. Preserve original `results/` and `logs/`; direct reruns write `rerun/`.

## Install the exact public closure

```bash
export VALIDATION_ROOT="$PWD"
python3.13 -m venv runtime
runtime/bin/python -m pip install --require-hashes --report rerun-installation.json -r public-requirements.lock
runtime/bin/python -m pip install --require-hashes --report rerun-test-installation.json -r full-test-requirements.lock
runtime/bin/python -m pip check
npm ci --ignore-scripts
npm --prefix legacy-consumer ci --ignore-scripts
npm audit signatures --json
unset PYTHONPATH
```

The second lock is the recorded test supplement plus all unchanged original pins. The original run added Moto/pytest-cov/pytest-timeout under `runtime-constraints.txt`; neither an editable install nor `--no-deps` is used. Do not add the extracted implementation directories to `PYTHONPATH`.

The evidence bundle includes exact extracted public source fixtures. To independently retrieve them, use `scripts/fetch_public.py` and the immutable archive URLs/commits in `results/released-source-fixtures.json`; check against `SHA256SUMS` and retained public metadata. All 36 provenance commands, owning repositories and retry results are in `results/provenance-verification.json`. Run each final command with `uvx --from pypi-attestations==0.0.30 pypi-attestations verify pypi --repository <recorded-owning-repository> <artifact>`. For S3, use the signed repository documented in `REPORT.md`.

## Reproduce the metadata defects without engines

```bash
runtime/bin/python scripts/export_manifests.py --extended
node scripts/audit_profiles.mjs --extended
```

Expected on the supplied exact consumer: 12 profiles, 28 combinations, 2,454 cases, 168 mismatches, 978 negatives, 96 negative failures. Both output documents are metadata evidence only. Run in a fresh bundle copy if preserving original files. The initial 1,146-case audit and its native attachment are retained separately.

## PostgreSQL 16, S3, OCI and plugins

```bash
export ARTIFACT_COMPOSE="$VALIDATION_ROOT/sources/meridian_plugin_config_artifact-1.1.1/tests/real_storage/compose.yaml"
docker compose -p t100654-artifact -f "$ARTIFACT_COMPOSE" up -d --wait
export MERIDIAN_POSTGRESQL_TEST_DSN='postgresql://meridian:meridian-fixture-only@127.0.0.1:55441/meridian'
export MERIDIAN_POSTGRESQL_ENGINE_VERSION='16-postgis-3.4'
export USAGE_TEST_POSTGRES_DSN="$MERIDIAN_POSTGRESQL_TEST_DSN"
export COST_TEST_POSTGRES_DSN="$MERIDIAN_POSTGRESQL_TEST_DSN"
export MERIDIAN_S3_ENDPOINT='http://127.0.0.1:59441'
export MERIDIAN_S3_ACCESS_KEY='meridian'
export MERIDIAN_S3_SECRET_KEY='meridian-fixture-only'
export MERIDIAN_S3_ENGINE_RELEASE='RELEASE.2025-04-22T22-12-26Z'
export MERIDIAN_S3_ENGINE_DIGEST='sha256:a1ea29fa28355559ef137d71fc570e508a214ec84ff8083e39bc5428980b015e'
export MERIDIAN_OCI_TEST_ENDPOINT='http://127.0.0.1:55442'
export MERIDIAN_OCI_TEST_REPOSITORY='conformance/validation'
export MERIDIAN_OCI_TEST_RELEASE='3.1.1'
export MERIDIAN_OCI_TEST_IMAGE='registry:3.1.1@sha256:1be55279f18a2fe1a74edf2664cac61c1bea305b7b4642dab412e7affdcb3e33'
runtime/bin/python scripts/run_selected.py postgresql16 --run
runtime/bin/python scripts/run_selected.py packed-host16 --run
runtime/bin/python scripts/run_selected.py projection-runner16 --run
runtime/bin/python scripts/run_selected.py s3-final --run
runtime/bin/python scripts/run_selected.py oci --run
runtime/bin/python scripts/run_selected.py config-artifact --run
runtime/bin/python scripts/run_selected.py cost --run
```

All credentials above are public disposable fixture credentials. The OCI selection explicitly executes four reference-registry/core/negative cases; it does not silently collect and skip the external owner-service or distinct S3-coexistence route.

Usage needs the ClickHouse fixture below. Keep the PostgreSQL fixture alive until Usage is complete. ConfigArtifact's fixture migration and its 21 acceptance/put-mode cases use its published default local ports and credentials.

## ClickHouse and Usage/Observability

```bash
export CH_FIXTURE="$VALIDATION_ROOT/sources/zephytiju-MeridianClickHouseAdapter-757b79b"
export CLICKHOUSE_IMAGE='clickhouse/clickhouse-server@sha256:0152dd511befe6a2c2ef53e930726179669b08116da78500b37c51c96ff5ee77'
export CLICKHOUSE_SELECTED_RELEASE='25.8'
export COMPOSE_PROJECT_NAME='t100654-clickhouse-suite'
export MERIDIAN_COMPOSE_FILE="$CH_FIXTURE/tests/integration/docker-compose.yml"
docker compose -f "$MERIDIAN_COMPOSE_FILE" up -d --wait
export CLICKHOUSE_INTEGRATION=1
export CLICKHOUSE_ENDPOINT='http://127.0.0.1:18123'
runtime/bin/python scripts/run_selected.py clickhouse-standalone --run
```

For the plugin gates an equivalent reproduction can reuse that server on port 18123 (the original plugin-only server used port 58423). Create the exact Usage test principal with sufficient privileges, then run the unchanged tests:

```bash
docker compose -f "$MERIDIAN_COMPOSE_FILE" exec -T clickhouse clickhouse-client --user meridian --password meridian-test --query "CREATE USER IF NOT EXISTS usage IDENTIFIED BY 'usage-test'"
docker compose -f "$MERIDIAN_COMPOSE_FILE" exec -T clickhouse clickhouse-client --user meridian --password meridian-test --query 'GRANT CURRENT GRANTS ON *.* TO usage'
export USAGE_TEST_CLICKHOUSE_PORT=18123
export USAGE_TEST_CLICKHOUSE_RELEASE='25.8'
export CLICKHOUSE_PORT=18123
runtime/bin/python scripts/run_selected.py usage --run
runtime/bin/python scripts/run_selected.py observability --run
docker compose -f "$MERIDIAN_COMPOSE_FILE" down -v
docker compose -p t100654-artifact -f "$ARTIFACT_COMPOSE" down -v

export COMPOSE_PROJECT_NAME='t100654-clickhouse-replicated'
export MERIDIAN_COMPOSE_FILE="$CH_FIXTURE/tests/cluster/docker-compose.yml"
export CLICKHOUSE_CLUSTER=1
docker compose -f "$MERIDIAN_COMPOSE_FILE" up -d --wait
runtime/bin/python scripts/run_selected.py clickhouse-replicated --run
docker compose -f "$MERIDIAN_COMPOSE_FILE" down -v
```

In the original evidence, Usage first had 44 passing tests and one permissions failure; only that unchanged final case was rerun after grant correction. The supplied matrix accounts for each case once and preserves both failed attempts. Reproduction with the corrected fixture should pass all 45 at once.

## PostgreSQL 17 local and both cluster versions

```bash
docker run -d --rm --name t100654-pg17 --platform linux/amd64 -p 127.0.0.1:55443:5432 -e POSTGRES_DB=meridian -e POSTGRES_USER=meridian -e POSTGRES_PASSWORD=meridian-fixture-only postgis/postgis@sha256:894f570c0cf0664ed5576a8fd5d5bfb8fb1b19d592885b686c3a88c8bd90c41f
# Wait for pg_isready to report accepting connections before testing.
docker exec t100654-pg17 pg_isready -U meridian -d meridian
export MERIDIAN_POSTGRESQL_TEST_DSN='postgresql://meridian:meridian-fixture-only@127.0.0.1:55443/meridian'
export MERIDIAN_POSTGRESQL_ENGINE_VERSION='17-postgis-3.5'
runtime/bin/python scripts/run_selected.py postgresql17 --run
runtime/bin/python scripts/run_selected.py packed-host17 --run
docker stop t100654-pg17

export MERIDIAN_POSTGRESQL_PYTHON="$VALIDATION_ROOT/runtime/bin/python"
export GITHUB_SHA='6110272c97c4586d3896f5e7fa4ebf91752869ae'
export MERIDIAN_POSTGRESQL_IMAGE='postgis/postgis@sha256:681931a625df344215e9b8998bf34daf146b6a395ceacee4439eb9c85869239f'
export MERIDIAN_POSTGRESQL_ENGINE_VERSION='16-postgis-3.4'
cd "$VALIDATION_ROOT/runs/postgresql16-cluster"
bash scripts/run-cluster-conformance.sh
export MERIDIAN_POSTGRESQL_IMAGE='postgis/postgis@sha256:894f570c0cf0664ed5576a8fd5d5bfb8fb1b19d592885b686c3a88c8bd90c41f'
export MERIDIAN_POSTGRESQL_ENGINE_VERSION='17-postgis-3.5'
cd "$VALIDATION_ROOT/runs/postgresql17-cluster"
bash scripts/run-cluster-conformance.sh
cd "$VALIDATION_ROOT"
```

The runner owns cluster provisioning and teardown and derives connection ports. `runs/` contains unchanged published test/conformance/contracts/examples/docs/scripts fixtures plus a scratch `pytest.ini` selecting installed imports. The original run required restoring omitted fixtures; final ten-case projection reruns used `run-projection-only.sh`, retained alongside the unchanged full script. The original recorder failed because the scratch directory had no Git metadata and `GITHUB_SHA` was absent. The true source SHA above addresses recorder metadata on reproduction; no successful original recorder run is claimed.

## Valkey, OpenSearch and Kafka

Run in a fresh bundle copy if preserving original results; these published runners write their native output paths. `PYTEST_ADDOPTS` suppresses source-tree pyproject import/coverage settings while leaving the tests unchanged.

```bash
export PYTEST_ADDOPTS='-c /dev/null -p no:cacheprovider'
export PYTHON="$VALIDATION_ROOT/runtime/bin/python"
cd "$VALIDATION_ROOT/sources/meridian_storage_valkey-1.1.0"
PYTEST_ADDOPTS="$PYTEST_ADDOPTS --junitxml=$VALIDATION_ROOT/rerun/valkey-standalone.xml" bash scripts/test-integration.sh
PYTEST_ADDOPTS="$PYTEST_ADDOPTS --junitxml=$VALIDATION_ROOT/rerun/valkey-failover.xml" bash scripts/test-failover.sh
cd "$VALIDATION_ROOT"
export MERIDIAN_PYTHON="$VALIDATION_ROOT/runtime/bin/python"
export OPENSEARCH_VERSION='2.19.1'
PYTEST_ADDOPTS="$PYTEST_ADDOPTS --junitxml=$VALIDATION_ROOT/rerun/opensearch-single.xml" bash sources/meridian_storage_opensearch-1.1.0/scripts/run-single-conformance.sh
bash scripts/run_opensearch_cluster.sh
cd "$VALIDATION_ROOT/sources/meridian_storage_kafka-1.1.0"
"$VALIDATION_ROOT/runtime/bin/python" conformance/scripts/run_cluster.py --kafka-version 4.3.1 --image apache/kafka@sha256:77e3df9054047a88b520d0cc46e16696d3b22022e1d580aeccd2632df6532837 --full
cd "$VALIDATION_ROOT"
unset PYTEST_ADDOPTS
```

Valkey scripts use the published fixed standalone/Sentinel project names and trap teardown. OpenSearch uses the public ICU Dockerfile and pinned base image; its cluster wrapper runs real operations, three-node and explicit node-loss phases and tears down the owned project. Inspect each JUnit for failures: the historical wrapper retains its original non-fail-fast behavior, so its shell exit alone is not acceptance. Kafka generates temporary TLS material and performs authenticated full disruption controls; its native evidence JSON/JUnit are retained in the original bundle.

## Inspect outcomes and cleanup

Use JUnit case counts, failure/error/skip attributes and per-route logs, not shell exit alone. The baseline is `results/route-matrix.json`. `scripts/prepare_report.py` reconstructs the original matrix, including explicit Usage retry accounting; it is not a generic rerun aggregator. Missing cloud/Collector/external OCI evidence stays unverified.

Use only the specific Compose projects/container names created by these commands for teardown, including on failure. Never use a global Docker prune. The original cleanup inventories and logs are in `results/cleanup-*.txt` and `logs/*cleanup.log`. Check that no task-owned container, network or volume remains.
