# Attempt 5 — Local operational conformance complete

Local acceptance passes on public Constructs 1.6.1, ClickHouse 1.1.3 and Core 1.1.0 with the exact 67-package Python lock. Both stock Collector modes pass independently. The 26 included local family/mode routes pass with explicitly verified reuse of unchanged actual engine and recovery evidence. Current user-approved scope excludes the two AWS/production variants from delivery; they are not marked verified.

## Fresh acceptance

Original A4 gateway/sidecar inputs render successfully without removing any layout fields or changing their identities. All eight formerly rejected omitted-manifest cases pass: the independent actual-layout matrix is 992/992, and the published configured matrix is 2,988/2,988. Ten public layout/contract tests retain legacy, mixed, malformed, atomic, fingerprint and bounds negatives. Existing limit comparisons (1,688), family metadata/Core checks (1,014), and the original 16 cases agree.

The public stock gateway and sidecar fixtures perform real plugin emission, generated-config Core append/query, log/span/metric typed reads, exact nanoseconds, canonical batch/row identity, 10,012 finite float64 comparisons, retry, merge, backend restart and acknowledged SIGKILL recovery. Distinct content at the same identity/time remains separate through terminating one-row public pagination, including integers beyond JavaScript's exact-number range. Original TLS, private relay, pre-ACK invalid input, rejected pin, scope isolation, repeat migration and old-table relabel negatives remain enabled. Actual backend query logs confirm zero DDL during both initial strict Core startups. First-run failure was solely serialization of immutable nested public result mappings in the extra evidence recorder; it is preserved, and the full fixture was rerun successfully.

`collector/full-mapping-probe.json`, `collector/*-core-one-row-pagination.json`, `collector/*-startup-query-audit.json`, `original-input-rerun.json`, and `contracts/` contain the outcomes. Source and fixture adaptation hashes/diffs distinguish unchanged public code from task-specific isolation and stronger evidence assertions. No product implementation was edited.

## Reuse and provenance

`release-comparison.json` shows only four JavaScript files changed: a shared ClickHouse layout parser, the Collector layout entry point, ClickHouse configured-guarantee derivation, and the exported version. All 67 Python distributions, all other npm dependencies, and provider/deployment/lifecycle/runtime-rendering code are unchanged. `reuse-assessment.json` records the exact component hashes.

`route-plans/results.json` proves all 24 family/mode plan objects and effective runtime configurations are byte-identical under public 1.6.0 and 1.6.1; all are parsed by current Core. Combined object bindings produce the 26 distinct local inventory routes. `legacy-byte-preservation.json` proves legacy Collector configuration and migration bytes are unchanged, while complete layout values and fingerprints remain preserved.

Actual CH standalone/replicated managed/external engine recovery remains A4 evidence: fresh appendOnly sorting-key/physical/capability locks; old-table and stale-lock rejection; 34 Core probes with identical retry batch IDs; disk and independent MinIO/SigV4 restoration into empty new volumes; 2→3 replica expansion and member/Keeper recovery. Other local engine evidence remains A3, including applicable earlier lifecycle evidence under its original scope. A5 does not relabel prior executions as freshly run on a newer package. The exact same effective plans, configs and execution code justify reuse; changed Collector behavior is independently rerun on 1.6.1.

The historical inventory assertion is deliberately preserved as a failure in `released-contracts-run.log` and its JUnit XML. `current-contract-inventory.json` proves its two differences are package-release provenance only (1.1.1 versus selected 1.1.3), with unchanged legacy capability fingerprints and schema. This does not mask a contract or runtime failure.

`public-artifact-verification.json` verifies all 90 installed npm product files and 18 Meridian wheel distributions against public registry artifacts, plus 67 actual Linux hash-locked downloads. The public npm tar SHA-256 is 36464cce62ffc6ec31d782a00f19b50a03d094388ae15a0b34f15fb5f5647afb. `observed-image-locks.json` retains exact stock image digests/layers. `source-provenance.json` identifies public merged source 266eb37bb22ffc429225726aecbddade06115569.

## Reproduction and cleanup

Use the original local fixture files or reacquire the exact public source and apply the recorded fixture deltas. Review-archive copies redact fixed disposable credential values and are not byte-identical executables; `PUBLICATION.json` distinguishes original and redacted hashes. `reproduce.sh` records the commands. All task-specific Docker containers, networks, volumes, temporary TLS/config directories and credentials are removed; public image caches and installed consumer dependencies remain. No cloud or production state was changed. See `cleanup.json` and the native task's attached archive.
